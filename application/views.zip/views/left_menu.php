<div class="navbar-collapse collapse templatemo-sidebar">
  <ul class="templatemo-sidebar-menu">   
        <li><a href="<?php echo $this->config->site_url()?>dashboard/index">List Quotation</a></li>
	<li> <a href="<?php echo $this->config->site_url()?>dashboard/add">Add Quotation</a></li>
    <li><a href="<?php echo $this->config->site_url()?>dashboard/searchquote"></i>Search Quote</a></li>
    <li><a href="<?php echo $this->config->site_url()?>dashboard/uploadexcel"></i>Upload Excel</a></li>	
    <li><a href="javascript:;" data-toggle="modal" data-target="#confirmModal">Sign Out</a></li>
  </ul>
</div><!--/.navbar-collapse -->